-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: ferre_update
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adm_departamento`
--

DROP TABLE IF EXISTS `adm_departamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adm_departamento` (
  `id_departamento` tinyint(2) NOT NULL AUTO_INCREMENT COMMENT 'llave primaria incremental',
  `departamento_nombre` varchar(150) NOT NULL COMMENT 'nombreo o descripcion del departamento',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_departamento`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adm_modulo`
--

DROP TABLE IF EXISTS `adm_modulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adm_modulo` (
  `id_modulo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_modulo` varchar(100) NOT NULL,
  `modulo_descripcion` varchar(180) NOT NULL COMMENT 'descripcion del modulo',
  `fa_menu` varchar(25) DEFAULT NULL,
  `mo_estado` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_modulo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adm_modulo_opcion`
--

DROP TABLE IF EXISTS `adm_modulo_opcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adm_modulo_opcion` (
  `id_modulo_opcion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_opcion` varchar(250) NOT NULL,
  `link` char(100) DEFAULT NULL,
  `opcion_nivel` tinyint(4) NOT NULL COMMENT 'nivel de la opcion, 1 opcion del menu raiz, 2 opcion del submenu raiz 1,  3 opcion del submenu 2, etc..',
  `opcion_estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'estado de la opcion 1=activo 0=inactiva',
  `id_modulo` int(11) NOT NULL COMMENT 'llave foranea para relacionar con la tabla adm_modulo, indice',
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `opcion_orden` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_modulo_opcion`),
  KEY `id_modulo` (`id_modulo`),
  CONSTRAINT `fk_moduloopcion_modulo` FOREIGN KEY (`id_modulo`) REFERENCES `adm_modulo` (`id_modulo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adm_modulo_opcion_usuario`
--

DROP TABLE IF EXISTS `adm_modulo_opcion_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adm_modulo_opcion_usuario` (
  `id_usuario` int(10) unsigned NOT NULL,
  `id_modulo_opcion` int(11) NOT NULL,
  `tiene_permiso` tinyint(1) DEFAULT 0,
  `agregar` tinyint(1) DEFAULT 0,
  `actualizar` tinyint(1) DEFAULT 0,
  `eliminar` tinyint(1) DEFAULT 0,
  UNIQUE KEY `id_usuario_id_opcion_menu` (`id_usuario`,`id_modulo_opcion`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_modulo_opcion` (`id_modulo_opcion`),
  CONSTRAINT `fk_moduloopcionenusuario_moduloopcion` FOREIGN KEY (`id_modulo_opcion`) REFERENCES `adm_modulo_opcion` (`id_modulo_opcion`) ON UPDATE CASCADE,
  CONSTRAINT `fk_moduloopcionenusuario_usuarios` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`codigousuario`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adm_municipio`
--

DROP TABLE IF EXISTS `adm_municipio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adm_municipio` (
  `id_municipio` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'llave primaria',
  `municipio_nombre` varchar(150) NOT NULL COMMENT 'nombre o descripcion del municipio',
  `id_departamento` tinyint(2) NOT NULL COMMENT 'llave foranea para relacionar con la tabla adm_departamento, indice',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_municipio`),
  KEY `id_departamento` (`id_departamento`),
  CONSTRAINT `fk_municipio_departamento` FOREIGN KEY (`id_departamento`) REFERENCES `adm_departamento` (`id_departamento`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adm_tipos_usuario`
--

DROP TABLE IF EXISTS `adm_tipos_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adm_tipos_usuario` (
  `id_tipo_usuario` smallint(6) NOT NULL AUTO_INCREMENT,
  `tipousu_nombre` varchar(25) NOT NULL,
  `tipousu_estado` tinyint(1) NOT NULL DEFAULT 1,
  `tipousu_fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `codigousuario` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_tipo_usuario`),
  KEY `codigousuario` (`codigousuario`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `com_compras`
--

DROP TABLE IF EXISTS `com_compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `com_compras` (
  `id_compra` int(11) NOT NULL AUTO_INCREMENT,
  `id_proveedor` int(11) NOT NULL,
  `com_codigo` varchar(15) NOT NULL COMMENT 'codiog del proveedor valor unico',
  `com_razon_social` varchar(250) NOT NULL COMMENT 'nombre de la razon social',
  `com_nombre_comercial` varchar(250) DEFAULT NULL,
  `com_nrc` varchar(8) NOT NULL COMMENT 'numero de registro del contribuyente',
  `com_nit` varchar(16) NOT NULL COMMENT 'numero de identificacion tributaria',
  `com_numero_documednto` varchar(15) DEFAULT NULL,
  `com_total` decimal(10,2) NOT NULL,
  `com_fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_compra`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `fk_compras_proveedores` FOREIGN KEY (`id_proveedor`) REFERENCES `com_proveedor` (`id_proveedor`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `com_compras_detalle`
--

DROP TABLE IF EXISTS `com_compras_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `com_compras_detalle` (
  `id_detalle_compra` int(11) NOT NULL AUTO_INCREMENT,
  `codigoproducto` int(10) unsigned NOT NULL,
  `det_cantidad` decimal(10,2) NOT NULL,
  `det_precio` decimal(10,2) NOT NULL,
  `det_sub_total` decimal(10,2) NOT NULL,
  `id_compra` int(11) NOT NULL,
  PRIMARY KEY (`id_detalle_compra`),
  KEY `codigoproducto` (`codigoproducto`),
  KEY `id_compra` (`id_compra`),
  CONSTRAINT `fk_comprasdetalle_compras` FOREIGN KEY (`id_compra`) REFERENCES `com_compras` (`id_compra`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_comprasdetalle_productos` FOREIGN KEY (`codigoproducto`) REFERENCES `productos` (`codigoproducto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `com_proveedor`
--

DROP TABLE IF EXISTS `com_proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `com_proveedor` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `pro_codigo` varchar(15) NOT NULL COMMENT 'codiog del proveedor valor unico',
  `pro_razon_social` varchar(250) NOT NULL COMMENT 'nombre de la razon social',
  `pro_nombre_comercial` varchar(250) DEFAULT NULL,
  `pro_nrc` varchar(8) NOT NULL COMMENT 'numero de registro del contribuyente',
  `pro_nit` varchar(17) NOT NULL COMMENT 'numero de identificacion tributaria',
  `pro_dui` varchar(10) DEFAULT NULL,
  `pro_direccion` varchar(250) DEFAULT NULL,
  `pro_telefono` varchar(9) DEFAULT NULL,
  `pro_estado` tinyint(1) NOT NULL DEFAULT 1,
  `pro_fecha_alta` datetime NOT NULL DEFAULT current_timestamp(),
  `id_municipio` smallint(6) NOT NULL,
  PRIMARY KEY (`id_proveedor`),
  UNIQUE KEY `pro_codigo` (`pro_codigo`),
  UNIQUE KEY `pro_nrc` (`pro_nrc`),
  KEY `id_municipio` (`id_municipio`),
  CONSTRAINT `fk_proveedor_municipio` FOREIGN KEY (`id_municipio`) REFERENCES `adm_municipio` (`id_municipio`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cotizacion`
--

DROP TABLE IF EXISTS `cotizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cotizacion` (
  `id_cotizacion` int(11) NOT NULL AUTO_INCREMENT,
  `numero_cotizacion` varchar(8) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `nombre_cliente` varchar(200) DEFAULT NULL,
  `terminos_condiciones` varchar(150) DEFAULT NULL,
  `codigousuario` int(10) unsigned NOT NULL,
  `codigocajero` int(10) unsigned DEFAULT NULL,
  `costo` decimal(10,2) NOT NULL,
  `estado` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT '0 no facturada, 1 facturada',
  `fecha_procesamiento` datetime DEFAULT NULL,
  `fecha_ultima_modificacion` datetime DEFAULT NULL,
  `id_cliente` int(11) NOT NULL,
  PRIMARY KEY (`id_cotizacion`),
  KEY `codigousuario` (`codigousuario`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `fk_cotizacion_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `fac_cliente` (`id_cliente`) ON UPDATE CASCADE,
  CONSTRAINT `fk_cotizacion_usuarios` FOREIGN KEY (`codigousuario`) REFERENCES `usuarios` (`codigousuario`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cotizacion_detalle`
--

DROP TABLE IF EXISTS `cotizacion_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cotizacion_detalle` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` decimal(12,2) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `id_cotizacion` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `codigoproducto` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_detalle`),
  KEY `id_cotizacion` (`id_cotizacion`),
  KEY `codigoproducto` (`codigoproducto`),
  CONSTRAINT `fk_coitaciondetalle_productos` FOREIGN KEY (`codigoproducto`) REFERENCES `productos` (`codigoproducto`) ON UPDATE CASCADE,
  CONSTRAINT `fk_cotizaciondetalle_cotizacion` FOREIGN KEY (`id_cotizacion`) REFERENCES `cotizacion` (`id_cotizacion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fac_cliente`
--

DROP TABLE IF EXISTS `fac_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fac_cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `cli_codigo` varchar(12) NOT NULL,
  `cli_nombre` varchar(125) NOT NULL,
  `cli_direccion` varchar(125) DEFAULT NULL,
  `cli_telefono` varchar(9) DEFAULT NULL,
  `cli_razon_social` varchar(125) NOT NULL,
  `cli_nombre_comercial` varchar(125) DEFAULT NULL,
  `cli_nrc` varchar(8) NOT NULL COMMENT 'numero de registro del contribuyente',
  `cli_nit` varchar(17) NOT NULL COMMENT 'numero de identificacion tributaria',
  `cli_dui` varchar(10) DEFAULT NULL,
  `cli_estado` tinyint(1) NOT NULL DEFAULT 1,
  `cli_fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `id_municipio` smallint(6) NOT NULL,
  PRIMARY KEY (`id_cliente`),
  UNIQUE KEY `cli_codigo` (`cli_codigo`),
  KEY `id_municipio` (`id_municipio`),
  CONSTRAINT `fk_cliente_municipio` FOREIGN KEY (`id_municipio`) REFERENCES `adm_municipio` (`id_municipio`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fac_factura`
--

DROP TABLE IF EXISTS `fac_factura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fac_factura` (
  `id_factura` int(11) NOT NULL AUTO_INCREMENT,
  `fac_fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `fac_nombre_cliente` varchar(200) DEFAULT NULL,
  `codigousuario` int(10) unsigned NOT NULL,
  `codigocajero` int(10) unsigned DEFAULT NULL,
  `fac_total` decimal(10,2) NOT NULL,
  `fac_estado` tinyint(1) NOT NULL DEFAULT 0,
  `id_cliente` int(11) NOT NULL,
  `fac_numero_factura` varchar(10) DEFAULT NULL,
  `id_cotizacion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_factura`),
  KEY `id_cliente` (`id_cliente`),
  KEY `codigousuario` (`codigousuario`),
  CONSTRAINT `fk_factura_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `fac_cliente` (`id_cliente`) ON UPDATE CASCADE,
  CONSTRAINT `fk_factura_usuario` FOREIGN KEY (`codigousuario`) REFERENCES `usuarios` (`codigousuario`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=327746 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fac_factura_detalle`
--

DROP TABLE IF EXISTS `fac_factura_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fac_factura_detalle` (
  `id_factura_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `facde_cantidad` decimal(12,2) NOT NULL,
  `facde_precio_venta` decimal(10,2) NOT NULL,
  `facde_subtotal` decimal(10,2) NOT NULL,
  `id_factura` int(10) NOT NULL,
  `codigoproducto` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_factura_detalle`),
  KEY `codigoproducto` (`codigoproducto`),
  KEY `id_factura` (`id_factura`),
  CONSTRAINT `fk_facturadetalle_factura` FOREIGN KEY (`id_factura`) REFERENCES `fac_factura` (`id_factura`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_facturadetalle_producto` FOREIGN KEY (`codigoproducto`) REFERENCES `productos` (`codigoproducto`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32979 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ferro_adm_configuraciones`
--

DROP TABLE IF EXISTS `ferro_adm_configuraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ferro_adm_configuraciones` (
  `id_configuracion` int(11) NOT NULL AUTO_INCREMENT,
  `conf_nombre_configuracion` longtext NOT NULL,
  `valor_configuracion` varchar(150) NOT NULL COMMENT 'valor asiganod a la configuraicon para ser utilizado, numeros o letras',
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_configuracion`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inv_entradas`
--

DROP TABLE IF EXISTS `inv_entradas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_entradas` (
  `id_entrada` int(11) NOT NULL AUTO_INCREMENT,
  `en_numero_documento` varchar(15) NOT NULL COMMENT 'Numero del documento',
  `en_comentario` varchar(250) DEFAULT NULL COMMENT 'comentario',
  `en_fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `en_total` decimal(10,2) DEFAULT NULL,
  `codigousuario` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_entrada`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inv_entradas_detalle`
--

DROP TABLE IF EXISTS `inv_entradas_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_entradas_detalle` (
  `id_entrada_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `codigoproducto` int(10) unsigned NOT NULL,
  `ende_cantidad` decimal(10,2) NOT NULL,
  `ende_precio` decimal(10,2) NOT NULL,
  `ende_sub_total` decimal(10,2) NOT NULL,
  `id_entrada` int(11) NOT NULL,
  PRIMARY KEY (`id_entrada_detalle`),
  KEY `codigoproducto` (`codigoproducto`),
  KEY `id_entrada` (`id_entrada`),
  CONSTRAINT `fk_entradadetalle_entradas` FOREIGN KEY (`id_entrada`) REFERENCES `inv_entradas` (`id_entrada`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_entradadetalle_productos` FOREIGN KEY (`codigoproducto`) REFERENCES `productos` (`codigoproducto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inv_kardex`
--

DROP TABLE IF EXISTS `inv_kardex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_kardex` (
  `id_kardex` int(11) NOT NULL AUTO_INCREMENT,
  `kar_fecha_creacion` datetime NOT NULL,
  `kar_tipo_transaccion` tinyint(1) NOT NULL COMMENT 'tipo operacion, 1=compra, 2=venta, 3= entradas, 4=salidas',
  `kar_numero_documento` varchar(15) DEFAULT NULL,
  `kar_cantidad` decimal(10,2) NOT NULL,
  `kar_saldo` decimal(10,2) NOT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `id_compra` int(11) DEFAULT NULL,
  `id_entrada` int(11) DEFAULT NULL COMMENT 'Para relacionar con la tabla inv_entradas',
  `id_salida` int(11) DEFAULT NULL COMMENT 'Para relacionar con la tabla inv_salidas',
  `codigoproducto` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_kardex`),
  KEY `codigoproducto` (`codigoproducto`),
  CONSTRAINT `fk_kardex_producto` FOREIGN KEY (`codigoproducto`) REFERENCES `productos` (`codigoproducto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2293 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inv_salidas`
--

DROP TABLE IF EXISTS `inv_salidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_salidas` (
  `id_salida` int(11) NOT NULL AUTO_INCREMENT,
  `sa_numero_documento` varchar(15) NOT NULL COMMENT 'Numero del documento',
  `sa_comentario` varchar(250) DEFAULT NULL COMMENT 'comentario',
  `sa_fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `sa_total` decimal(10,2) DEFAULT NULL,
  `codigousuario` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_salida`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inv_salidas_detalle`
--

DROP TABLE IF EXISTS `inv_salidas_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_salidas_detalle` (
  `id_salida_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `codigoproducto` int(10) unsigned NOT NULL,
  `salde_cantidad` decimal(10,2) NOT NULL,
  `salde_precio` decimal(10,2) NOT NULL,
  `salde_sub_total` decimal(10,2) NOT NULL,
  `id_salida` int(11) NOT NULL,
  PRIMARY KEY (`id_salida_detalle`),
  KEY `codigoproducto` (`codigoproducto`),
  KEY `id_salida` (`id_salida`),
  CONSTRAINT `fk_salidadetalle_productos` FOREIGN KEY (`codigoproducto`) REFERENCES `productos` (`codigoproducto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_salidadetalle_salidas` FOREIGN KEY (`id_salida`) REFERENCES `inv_salidas` (`id_salida`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `opciones_menu`
--

DROP TABLE IF EXISTS `opciones_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opciones_menu` (
  `id_opcion` int(11) NOT NULL AUTO_INCREMENT,
  `opcion_nombre` varchar(150) NOT NULL,
  `opcion_estado` tinyint(1) DEFAULT 1,
  `fecha_alta` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_opcion`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prod_precios`
--

DROP TABLE IF EXISTS `prod_precios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prod_precios` (
  `id_precio` int(11) NOT NULL AUTO_INCREMENT,
  `pre_precio` decimal(10,2) NOT NULL,
  `pre_fecha_creacion` datetime NOT NULL,
  `codigoproducto` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_precio`),
  KEY `codigoproducto` (`codigoproducto`),
  CONSTRAINT `fk_precios_producto` FOREIGN KEY (`codigoproducto`) REFERENCES `productos` (`codigoproducto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1880 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prod_tipo_unidad`
--

DROP TABLE IF EXISTS `prod_tipo_unidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prod_tipo_unidad` (
  `id_tipo_unidad` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_unidad_nombre` varchar(25) NOT NULL,
  `tipo_fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_tipo_unidad`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prod_tipos`
--

DROP TABLE IF EXISTS `prod_tipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prod_tipos` (
  `id_tipo_producto` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_nombre` varchar(25) NOT NULL,
  `tipo_fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_tipo_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `codigoproducto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prod_codigo` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `medida` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(300) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_tipo_producto` int(11) NOT NULL,
  `id_tipo_unidad` int(11) NOT NULL,
  `prod_fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`codigoproducto`),
  UNIQUE KEY `prod_codigo` (`prod_codigo`),
  KEY `id_tipo_producto` (`id_tipo_producto`),
  KEY `id_tipo_unidad` (`id_tipo_unidad`),
  CONSTRAINT `fk_productos_tipoproducto` FOREIGN KEY (`id_tipo_producto`) REFERENCES `prod_tipos` (`id_tipo_producto`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2073 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usuario_opciones`
--

DROP TABLE IF EXISTS `usuario_opciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_opciones` (
  `id_usuario` int(10) unsigned NOT NULL,
  `id_opcion` int(11) NOT NULL,
  `tiene_permiso` tinyint(1) DEFAULT 0,
  UNIQUE KEY `id_usuario_id_opcion_menu` (`id_usuario`,`id_opcion`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_opcion` (`id_opcion`),
  CONSTRAINT `fk_usuarioopcion_opcionesmenu` FOREIGN KEY (`id_opcion`) REFERENCES `opciones_menu` (`id_opcion`) ON UPDATE CASCADE,
  CONSTRAINT `fk_usuariopcion_usuarios` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`codigousuario`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `codigousuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombreusuario` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `id_tipo_usuario` smallint(6) NOT NULL COMMENT '1= administrador, 2= cajero, 3= vendedor',
  `contrasena` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `departamento` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `municipio` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(9) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`codigousuario`),
  KEY `id_tipo_usuario` (`id_tipo_usuario`),
  CONSTRAINT `fk_usuarios_tiposusuarios` FOREIGN KEY (`id_tipo_usuario`) REFERENCES `adm_tipos_usuario` (`id_tipo_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'ferre_update'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-04  7:54:50
